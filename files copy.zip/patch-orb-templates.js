// Run from: ~/Desktop/aurora-agent
// Usage: node patch-orb-templates.js

const fs = require('fs');
const path = require('path');

const dir = __dirname;
const mferFile = path.join(dir, 'modules/mfer-meme.js');

let code = fs.readFileSync(mferFile, 'utf8');

const tplOrbLandscape = fs.readFileSync(path.join(dir, 'tpl-orb-landscape.txt'), 'utf8');
const tplTwoOrbs      = fs.readFileSync(path.join(dir, 'tpl-two-orbs.txt'), 'utf8');
const tplOrbMeme      = fs.readFileSync(path.join(dir, 'tpl-orb-meme.txt'), 'utf8');

// 1. Replace existing orb-landscape
const oldOrbRx = /\/\/ ── ORB LANDSCAPE[^\n]*\n\s*'orb-landscape': \{[\s\S]*?\n  \},\n/;
if (oldOrbRx.test(code)) {
  code = code.replace(oldOrbRx, tplOrbLandscape + '\n');
  console.log('✅ orb-landscape replaced');
} else {
  console.log('⚠️  orb-landscape pattern not found, will append');
}

// 2. Add two-orbs and orb-meme before closing }; of TEMPLATES object
const insertIdx = code.lastIndexOf('\n};\n\nmodule.exports');
if (insertIdx !== -1) {
  code = code.slice(0, insertIdx) + '\n' + tplTwoOrbs + '\n' + tplOrbMeme + code.slice(insertIdx);
  console.log('✅ two-orbs added');
  console.log('✅ orb-meme added');
} else {
  console.log('⚠️  Could not find TEMPLATES closing bracket');
  process.exit(1);
}

fs.writeFileSync(mferFile, code);
console.log('\n✅ Done! mfer-meme.js patched with 3 orb templates.');
console.log('\nTest with:');
console.log("  node -e \"const m=require('./modules/mfer-meme');const r=m.generateMeme('orb-landscape',{top:'onchain',bottom:'forever'});require('fs').writeFileSync('/tmp/test-orb.svg',r.svg);console.log('wrote /tmp/test-orb.svg');\"");
console.log("  node -e \"const m=require('./modules/mfer-meme');const r=m.generateMeme('orb-meme',{top:'a footprint',bottom:'is not the foot'});require('fs').writeFileSync('/tmp/test-orb-meme.svg',r.svg);console.log('wrote /tmp/test-orb-meme.svg');\"");
console.log("  node -e \"const m=require('./modules/mfer-meme');const r=m.generateMeme('two-orbs',{left:'onchain',right:'offchain'});require('fs').writeFileSync('/tmp/test-two-orbs.svg',r.svg);console.log('wrote /tmp/test-two-orbs.svg');\"");
